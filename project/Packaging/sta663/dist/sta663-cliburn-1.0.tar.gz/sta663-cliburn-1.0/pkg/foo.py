def f1():
    return 1

def f2():
    return 2
