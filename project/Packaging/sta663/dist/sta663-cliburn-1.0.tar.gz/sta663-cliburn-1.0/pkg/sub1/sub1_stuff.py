def g1():
    return "g1"

def g2():
    return "g2"
